package com.fastclient.client;

import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.text.Text;

public final class FastClientScreen extends Screen {
    private int panelX, panelY;
    public FastClientScreen() { super(Text.literal("FAST CLIENT 2.0")); }

    @Override
    protected void init() {
        int w = 220, h = 214;
        panelX = (width - w) / 2; panelY = (height - h) / 2;
        int bx = panelX + 16, bw = w - 32, bh = 22, gap = 7;
        int y = panelY + 48;
        addDrawableChild(toggle("HUD", () -> FastClient.hudEnabled, v -> FastClient.hudEnabled = v, bx, y, bw, bh)); y += bh + gap;
        addDrawableChild(toggle("FPS counter", () -> FastClient.showFps, v -> FastClient.showFps = v, bx, y, bw, bh)); y += bh + gap;
        addDrawableChild(toggle("Keystrokes", () -> FastClient.showKeystrokes, v -> FastClient.showKeystrokes = v, bx, y, bw, bh)); y += bh + gap;
        addDrawableChild(toggle("Armor HUD", () -> FastClient.showArmor, v -> FastClient.showArmor = v, bx, y, bw, bh)); y += bh + gap;
        addDrawableChild(toggle("Coordinates", () -> FastClient.showCoords, v -> FastClient.showCoords = v, bx, y, bw, bh));
        addDrawableChild(ButtonWidget.builder(Text.literal("Done"), b -> close()).dimensions(bx, panelY + h - 31, bw, 22).build());
    }

    private ButtonWidget toggle(String name, java.util.function.BooleanSupplier getter,
                                 java.util.function.Consumer<Boolean> setter, int x, int y, int w, int h) {
        return ButtonWidget.builder(Text.literal(name + ": " + (getter.getAsBoolean() ? "ON" : "OFF")), b -> {
            boolean next = !getter.getAsBoolean(); setter.accept(next);
            b.setMessage(Text.literal(name + ": " + (next ? "ON" : "OFF")));
        }).dimensions(x, y, w, h).build();
    }

    @Override
    public void render(DrawContext ctx, int mouseX, int mouseY, float delta) {
        renderBackground(ctx, mouseX, mouseY, delta);
        int w = 220, h = 214;
        ctx.fill(panelX, panelY, panelX + w, panelY + h, 0xF0120D1B);
        ctx.fill(panelX, panelY, panelX + w, panelY + 3, FastClient.PURPLE);
        ctx.drawBorder(panelX, panelY, w, h, 0xFF7040A0);
        ctx.drawCenteredTextWithShadow(textRenderer, Text.literal("FAST CLIENT 2.0"), width / 2, panelY + 13, 0xFFFFFFFF);
        ctx.drawCenteredTextWithShadow(textRenderer, Text.literal("PURPLE EDITION  •  FABRIC 1.21.4"), width / 2, panelY + 29, FastClient.PURPLE);
        super.render(ctx, mouseX, mouseY, delta);
    }

    @Override public boolean shouldPause() { return false; }
}
