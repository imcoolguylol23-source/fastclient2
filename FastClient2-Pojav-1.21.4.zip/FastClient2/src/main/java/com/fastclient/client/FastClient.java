package com.fastclient.client;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.fabricmc.fabric.api.client.rendering.v1.HudRenderCallback;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.util.InputUtil;
import net.minecraft.text.Text;
import org.lwjgl.glfw.GLFW;

public final class FastClient implements ClientModInitializer {
    public static final int PURPLE = 0xFFB56BFF;
    public static final int PANEL = 0xE9161022;
    public static boolean hudEnabled = true;
    public static boolean showFps = true;
    public static boolean showCoords = false;
    public static boolean showKeystrokes = true;
    public static boolean showArmor = true;
    private static KeyBinding openMenu;

    @Override
    public void onInitializeClient() {
        openMenu = KeyBindingHelper.registerKeyBinding(new KeyBinding(
                "key.fastclient.open_menu", InputUtil.Type.KEYSYM, GLFW.GLFW_KEY_RIGHT_SHIFT,
                "category.fastclient"));
        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            while (openMenu.wasPressed()) client.setScreen(new FastClientScreen());
        });
        HudRenderCallback.EVENT.register((drawContext, tickCounter) -> renderHud(drawContext));
    }

    private static void renderHud(DrawContext ctx) {
        MinecraftClient mc = MinecraftClient.getInstance();
        if (!hudEnabled || mc.player == null || mc.options.hudHidden) return;
        int x = 8, y = 8;
        if (showFps) {
            String label = "FAST CLIENT 2.0  |  " + mc.getCurrentFps() + " FPS";
            ctx.fill(x - 4, y - 3, x + mc.textRenderer.getWidth(label) + 7, y + 13, PANEL);
            ctx.fill(x - 4, y - 3, x - 1, y + 13, PURPLE);
            ctx.drawTextWithShadow(mc.textRenderer, label, x, y, 0xFFFFFFFF);
            y += 20;
        }
        if (showCoords) {
            String coords = String.format("XYZ: %.1f / %.1f / %.1f", mc.player.getX(), mc.player.getY(), mc.player.getZ());
            ctx.fill(x - 4, y - 3, x + mc.textRenderer.getWidth(coords) + 7, y + 13, PANEL);
            ctx.drawTextWithShadow(mc.textRenderer, coords, x, y, PURPLE);
            y += 20;
        }
        if (showKeystrokes) {
            int bx = 8, by = mc.getWindow().getScaledHeight() - 62;
            String[] keys = {"W", "A", "S", "D", "SPACE"};
            int[] codes = {GLFW.GLFW_KEY_W, GLFW.GLFW_KEY_A, GLFW.GLFW_KEY_S, GLFW.GLFW_KEY_D, GLFW.GLFW_KEY_SPACE};
            for (int i = 0; i < keys.length; i++) {
                int xx = bx + (i == 0 ? 22 : i == 1 ? 0 : i == 2 ? 22 : i == 3 ? 44 : 0);
                int yy = by + (i == 0 ? 0 : i == 4 ? 44 : 22);
                int ww = i == 4 ? 66 : 20;
                boolean down = InputUtil.isKeyPressed(mc.getWindow().getHandle(), codes[i]);
                ctx.fill(xx, yy, xx + ww, yy + 19, down ? 0xFF593080 : PANEL);
                ctx.drawBorder(xx, yy, ww, 19, PURPLE);
                int tw = mc.textRenderer.getWidth(keys[i]);
                ctx.drawTextWithShadow(mc.textRenderer, keys[i], xx + (ww - tw) / 2, yy + 5, 0xFFFFFFFF);
            }
        }
        if (showArmor) {
            int yy = mc.getWindow().getScaledHeight() - 14;
            int xx = 8;
            String armor = "ARMOR " + mc.player.getArmor();
            ctx.fill(xx - 4, yy - 3, xx + mc.textRenderer.getWidth(armor) + 7, yy + 10, PANEL);
            ctx.drawTextWithShadow(mc.textRenderer, armor, xx, yy, PURPLE);
        }
    }
}
