# FAST CLIENT 2.0 — Purple Edition

A lightweight, client-side Fabric mod for Minecraft Java 1.21.4, designed with PojavLauncher in mind.

## Features in this starter release
- Right Shift opens a custom purple client menu.
- Toggleable FPS label, keystrokes, armor value, and coordinates.
- Lightweight HUD drawing; no shaders or Sodium dependency.
- Client-only: does not need to be installed on a server.

## Build the mod JAR
Requires Java 21 and Gradle 8.10.2 or newer.

From this folder run:

```sh
gradle build
```

The output JAR will be in `build/libs/fast-client-2-2.0.0.jar`.

## Install in PojavLauncher
1. Use a Fabric 1.21.4 profile.
2. Make sure Fabric API for 1.21.4 is installed.
3. Copy `fast-client-2-2.0.0.jar` into `.minecraft/mods`.
4. Launch the Fabric 1.21.4 profile.
5. In-game, press **Right Shift** to open the menu.

## Notes
This is a real source project, not a precompiled JAR. Build it on a computer with Java 21 and internet access so Gradle can download Minecraft/Fabric dependencies. It intentionally avoids claiming FPS gains: it provides a small HUD/client menu and does not include risky combat automation or server-cheat features.
